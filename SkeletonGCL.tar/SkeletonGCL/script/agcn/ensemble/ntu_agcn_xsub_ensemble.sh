python ensemble.py --dataset ntu/xsub \
--joint-dir work_dir/ntu/xsub/agcn_SkeletonGCL_joint \
--bone-dir work_dir/ntu/xsub/agcn_SkeletonGCL_bone \
--joint-motion-dir work_dir/ntu/xsub/agcn_SkeletonGCL_joint_motion \
--bone-motion-dir work_dir/ntu/xsub/agcn_SkeletonGCL_bone_motion