python ensemble.py --dataset ntu120/xset \
--joint-dir work_dir/ntu120/xset/agcn_SkeletonGCL_joint \
--bone-dir work_dir/ntu120/xset/agcn_SkeletonGCL_bone \
--joint-motion-dir work_dir/ntu120/xset/agcn_SkeletonGCL_joint_motion \
--bone-motion-dir work_dir/ntu120/xset/agcn_SkeletonGCL_bone_motion